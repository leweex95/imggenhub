﻿# main.py
import argparse
import subprocess
import logging
from pathlib import Path
from .core.deploy import deploy_kaggle_notebook, sync_hf_token
from imggenhub.kaggle.core import download
from imggenhub.kaggle.core.parallel_deploy import run_parallel_pipeline, should_use_parallel
from imggenhub.kaggle.utils import poll_status
from imggenhub.kaggle.utils.prompts import resolve_prompts, save_prompt_mapping
from imggenhub.kaggle.utils.cli import log_cli_command, setup_output_directory
from imggenhub.kaggle.utils.filesystem import ensure_output_directory
from imggenhub.kaggle.utils.arg_validator import validate_args
from imggenhub.kaggle.utils.config_loader import load_kaggle_config
from imggenhub.kaggle.utils.model_family import (
    MODEL_FAMILY_FLUX_BF16,
    MODEL_FAMILY_FLUX_GGUF,
    MODEL_FAMILY_QWEN_IMAGE,
    MODEL_FAMILY_SD35,
    MODEL_FAMILY_WAN21_CHROMA,
    detect_model_family,
    is_flux_bf16_model,
    is_flux_gguf_model,
    supports_sdxl_refiner,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


def run_pipeline(dest_path, prompts_file, notebook, kernel_path, gpu=False, model_id=None, refiner_model_id=None, prompt=None, prompts=None, guidance=None, steps=None, precision=None, negative_prompt=None, refiner_guidance=None, refiner_steps=None, refiner_precision=None, refiner_negative_prompt=None, img_size=None, model_filename=None, vae_repo_id=None, vae_filename=None, clip_l_repo_id=None, clip_l_filename=None, t5xxl_repo_id=None, t5xxl_filename=None, wait_timeout=None, sync_token=False, index_offset=0, kernel_id=None):
    """Run Kaggle image generation pipeline: sync HF token -> deploy -> poll -> download"""
    print("Initializing run_pipeline in main.py...")
    cwd = Path(__file__).parent

    # Load Kaggle config
    config = load_kaggle_config()
    if wait_timeout is None:
        wait_timeout = config.get("deployment_timeout_minutes", 30)
    
    retry_interval = config.get("retry_interval_seconds", 60)

    # Sync HF token to Kaggle dataset before deployment
    if sync_token:
        logging.info("Syncing HF token to Kaggle dataset...")
        try:
            updated = sync_hf_token()
            if updated:
                logging.info("HF token dataset updated successfully")
            else:
                logging.info("HF token dataset is already up-to-date")
        except Exception as e:
            raise RuntimeError(f"Failed to sync HF token: {e}") from e

    # Resolve paths
    base_pkg_path = Path(__file__).parent
    
    if prompts_file:
        prompts_file = Path(prompts_file)
        if not prompts_file.is_absolute():
            prompts_file = cwd / prompts_file

    kernel_path = Path(kernel_path)
    if not kernel_path.is_absolute():
        kernel_path = cwd / kernel_path  # Respect user-provided kernel path

    notebook = Path(notebook)
    if not notebook.is_absolute():
        # 1. Try resolving relative to package notebooks/ folder
        pkg_notebook = base_pkg_path / "notebooks" / notebook.name
        # 2. Try resolving relative to kernel_path (backward compatibility)
        alt_notebook = kernel_path / notebook.name
        
        if pkg_notebook.exists():
            notebook = pkg_notebook
        elif alt_notebook.exists():
            notebook = alt_notebook
        else:
            # Otherwise resolve relative to the current directory
            notebook = cwd / notebook

    prompts_list = resolve_prompts(prompts_file, prompt)
    save_prompt_mapping(dest_path, prompts_list)

    logging.debug(f"Resolved paths:\n prompts_file={prompts_file}\n notebook={notebook}\n kernel_path={kernel_path}\n dest={dest_path}")

    # Check if parallel deployment should be used (prompts > 4)
    if should_use_parallel(prompts_list):
        logging.info("="*80)
        logging.info(f"PARALLEL MODE: {len(prompts_list)} prompts detected (threshold: 4)")
        logging.info("Splitting prompts across 2 Kaggle kernels for parallel execution")
        logging.info("="*80)
        
        # Build deploy kwargs for parallel pipeline
        deploy_kwargs = {
            "model_id": model_id,
            "gpu": gpu,
            "refiner_model_id": refiner_model_id,
            "guidance": guidance,
            "steps": steps,
            "precision": precision,
            "negative_prompt": negative_prompt,
            "output_dir": dest_path.name,
            "refiner_guidance": refiner_guidance,
            "refiner_steps": refiner_steps,
            "refiner_precision": refiner_precision,
            "refiner_negative_prompt": refiner_negative_prompt,
            "img_size": img_size,
            "model_filename": model_filename,
            "vae_repo_id": vae_repo_id,
            "vae_filename": vae_filename,
            "clip_l_repo_id": clip_l_repo_id,
            "clip_l_filename": clip_l_filename,
            "t5xxl_repo_id": t5xxl_repo_id,
            "t5xxl_filename": t5xxl_filename,
            "index_offset": index_offset,
        }
        
        run_parallel_pipeline(
            dest_path=dest_path,
            prompts_list=prompts_list,
            notebook=notebook,
            kernel_path=kernel_path,
            wait_timeout=wait_timeout,
            retry_interval=retry_interval,
            polling_interval=config.get("polling_interval_seconds", 60),
            **deploy_kwargs
        )
        
        logging.info(f"Pipeline completed! Output saved to: {dest_path}")
        logging.info("Check remaining GPU quota: https://www.kaggle.com/settings#quotas")
        return

    # Sequential deployment for 4 or fewer prompts
    logging.info("Deploying kernel...")
    # Pass only the run name (e.g., '20251115_182905') so the notebook can
    # prepend 'output/' itself and avoid creating nested output paths.
    deploy_kaggle_notebook(
        prompts_list=prompts_list,
        notebook=notebook,
        model_id=model_id,
        kernel_path=kernel_path,
        gpu=gpu,
        refiner_model_id=refiner_model_id,
        guidance=guidance,
        steps=steps,
        precision=precision,
        negative_prompt=negative_prompt,
        output_dir=dest_path.name,
        refiner_guidance=refiner_guidance,
        refiner_steps=refiner_steps,
        refiner_precision=refiner_precision,
        refiner_negative_prompt=refiner_negative_prompt,
        img_size=img_size,
        model_filename=model_filename,
        vae_repo_id=vae_repo_id,
        vae_filename=vae_filename,
        clip_l_repo_id=clip_l_repo_id,
        clip_l_filename=clip_l_filename,
        t5xxl_repo_id=t5xxl_repo_id,
        t5xxl_filename=t5xxl_filename,
        wait_timeout=wait_timeout,
        retry_interval=retry_interval,
        kernel_id=kernel_id,
        index_offset=index_offset
    )
    logging.debug("Deploy step completed")

    # Step 2: Poll status
    logging.info("Polling kernel status...")
    status = poll_status.run(poll_interval=config.get("polling_interval_seconds", 60))
    logging.debug("Poll status completed")

    # Step 3: Download output (using selective downloader to get only images and logs)
    logging.info("Downloading output artifacts...")
    # Use provided kernel_id or fallback to default
    if not kernel_id:
        username = config.get('kaggle_username') or "leventecsibi"
        kernel_id = f"{username}/stable-diffusion-batch-generator"
    
    success = download.run(kernel_id=kernel_id, dest=str(dest_path))
    logging.debug("Download completed")

    if status == "kernelworkerstatus.error":
        # Look for log file in destination
        log_files = list(dest_path.glob("*.log"))
        log_msg = f"See log: {log_files[0]}" if log_files else "Log file not found."
        logging.error(f"Kernel failed. {log_msg}")
        raise RuntimeError("Kaggle kernel failed during image generation. Aborting pipeline.")

    if not success:
        logging.warning("Selective download did not complete successfully")

    # Validate image count for sequential deployment
    if not should_use_parallel(prompts_list):
        image_extensions = {".png", ".jpg", ".jpeg"}
        actual_images = len([f for f in dest_path.rglob("*") if f.is_file() and f.suffix.lower() in image_extensions])
        expected_images = len(prompts_list)
        if actual_images != expected_images:
            logging.error(f"Incomplete image generation: expected {expected_images} images but got {actual_images}")
            raise RuntimeError(
                f"Image generation incomplete: expected {expected_images} images "
                f"but only got {actual_images}. Some prompts failed to generate images."
            )

    logging.info(f"Pipeline completed! Output saved to: {dest_path}")
    logging.info("Check remaining GPU quota: https://www.kaggle.com/settings#quotas")


def main():
    """Main entry point - focused on argument parsing and orchestration"""
    # First parser for early args only (no help to avoid conflicts)
    early_parser = argparse.ArgumentParser(add_help=False)
    early_parser.add_argument("--dest", type=str, default=None)
    early_parser.add_argument("--output-base-dir", dest="output_base_dir", type=str, default=None)
    
    # Parse only known args to get output_base_dir and dest early
    early_args, remaining = early_parser.parse_known_args()
    
    # Set up output directory and log CLI command early
    dest_path = setup_output_directory(base_name=early_args.dest, base_dir=early_args.output_base_dir)
    log_cli_command(dest_path)

    # Parse full command line arguments
    parser = argparse.ArgumentParser(description="Kaggle image generation pipeline")
    parser.add_argument("--prompts-file", dest="prompts_file", type=str, default="./config/prompts.json")
    parser.add_argument("--notebook", type=str, default=None, help="Notebook to use (auto-detects based on model if not specified)")
    parser.add_argument("--kernel-id", dest="kernel_id", type=str, default=None, help="Specific Kaggle kernel ID to use (e.g. 'username/slug')")
    parser.add_argument("--kernel-path", dest="kernel_path", type=str, default="./config")
    parser.add_argument("--gpu", action="store_true", help="Enable GPU for the kernel")
    parser.add_argument("--dest", type=str, default=None, help="Optional prefix for output folder (default: timestamp only)")
    parser.add_argument("--output-base-dir", dest="output_base_dir", type=str, default=None, help="Base directory for output runs (default: current working directory)")
    parser.add_argument("--model-id", dest="model_id", type=str, default=None, help="Model ID (HuggingFace repo ID) for all models. For quantized models, use GGUF repo ID.")
    parser.add_argument("--refiner-model-id", dest="refiner_model_id", type=str, default=None, help="Refiner model ID (HuggingFace repo ID) for SDXL refiner.")
    parser.add_argument("--prompt", action='append', default=None, help="Prompt(s) for generation. Can be used multiple times for multiple prompts. For many prompts, use --prompts-file.")
    parser.add_argument("--guidance", type=float, required=True, help="Guidance scale (7-12 recommended for photorealism)")
    parser.add_argument("--steps", type=int, required=True, help="Number of inference steps (50-100 for better quality)")
    parser.add_argument("--precision", type=str, required=True, choices=["fp32", "fp16", "bf16", "int8", "int4", "q4", "q5", "q6", "q8"],
                        help="Precision level (REQUIRED): fp32 (highest quality), fp16 (balanced), bf16 (recommended for Flux), q4/q5/q6/q8 (GGUF quantized), int8 (faster), int4 (fastest)")
    parser.add_argument("--negative-prompt", dest="negative_prompt", type=str, default=None, help="Custom negative prompt for better quality control")
    parser.add_argument("--refiner-guidance", dest="refiner_guidance", type=float, default=None, help="STABLE DIFFUSION ONLY: Guidance scale for refiner (REQUIRED when using --refiner-model-id). Ignored for Flux models.")
    parser.add_argument("--refiner-steps", dest="refiner_steps", type=int, default=None, help="STABLE DIFFUSION ONLY: Number of inference steps for refiner (REQUIRED when using --refiner-model-id). Ignored for Flux models.")
    parser.add_argument("--refiner-precision", dest="refiner_precision", type=str, default=None, choices=["fp32", "fp16", "bf16", "int8", "int4"],
                        help="STABLE DIFFUSION ONLY: Precision level for refiner (REQUIRED when using --refiner-model-id, or inherits from --precision). Ignored for Flux models.")
    parser.add_argument("--refiner-negative-prompt", dest="refiner_negative_prompt", type=str, default=None, help="STABLE DIFFUSION ONLY: Custom negative prompt for refiner (defaults to same as --negative-prompt). Ignored for Flux models.")
    parser.add_argument("--img-width", dest="img_width", type=int, default=None, help="Image width (defaults: 1024 for stable diffusion, 512 for flux gguf)")
    parser.add_argument("--img-height", dest="img_height", type=int, default=None, help="Image height (defaults: 1024 for stable diffusion, 512 for flux gguf)")
    parser.add_argument("--wait-timeout", dest="wait_timeout", type=int, default=None, help="Maximum wait time in minutes for GPU availability (overrides YAML config)")
    parser.add_argument("--sync-token", action="store_true", help="Sync local HF_TOKEN to Kaggle dataset before deployment")
    parser.add_argument("--index-offset", type=int, default=0, help="Offset for image indexing (useful for parallel runs)")
    
    # FLUX GGUF model configuration (quantized models only)
    parser.add_argument("--model-filename", dest="model_filename", type=str, default=None, help="Model filename for quantized GGUF models (e.g., flux1-schnell-Q4_0.gguf)")
    parser.add_argument("--vae-repo-id", dest="vae_repo_id", type=str, default=None, help="FLUX GGUF ONLY: HuggingFace repo ID for VAE model (auto-resolved if not provided)")
    parser.add_argument("--vae-filename", dest="vae_filename", type=str, default=None, help="FLUX GGUF ONLY: VAE model filename (auto-resolved if not provided)")
    parser.add_argument("--clip-l-repo-id", dest="clip_l_repo_id", type=str, default=None, help="FLUX GGUF ONLY: HuggingFace repo ID for CLIP-L text encoder (auto-resolved if not provided)")
    parser.add_argument("--clip-l-filename", dest="clip_l_filename", type=str, default=None, help="FLUX GGUF ONLY: CLIP-L model filename (auto-resolved if not provided)")
    parser.add_argument("--t5xxl-repo-id", dest="t5xxl_repo_id", type=str, default=None, help="FLUX GGUF ONLY: HuggingFace repo ID for T5-XXL text encoder (auto-resolved if not provided)")
    parser.add_argument("--t5xxl-filename", dest="t5xxl_filename", type=str, default=None, help="FLUX GGUF ONLY: T5-XXL model filename (auto-resolved if not provided)")

    args = parser.parse_args()
    model_family = detect_model_family(args.model_id, args.model_filename)

    # Validate arguments strictly before any auto-detection or notebook selection
    try:
        validate_args(args)
    except ValueError as e:
        print(f"Error: {e}")
        return

    # Check for missing image dimensions before notebook auto-detection
    if args.img_width is None or args.img_height is None:
        print("\n" + "="*80)
        print("VALIDATION ERROR: MISSING IMAGE DIMENSIONS!")
        print("="*80)
        print("Both --img-width and --img-height are REQUIRED.")
        print("Please specify explicit image dimensions.")
        print("Examples:")
        print("  - Stable Diffusion XL: --img-width 1024 --img-height 1024")
        print("  - FLUX GGUF Q4: --img-width 512 --img-height 512")
        print("="*80 + "\n")
        return

    # Auto-detect notebook based on model type if not specified
    if args.notebook is None:
        print(f"Detected model family: {model_family}")
        if model_family == MODEL_FAMILY_FLUX_GGUF:
            args.notebook = "./notebooks/kaggle-flux-gguf.ipynb"
            print(f"Auto-detected FLUX GGUF model, using notebook: {args.notebook}")
            # Enforce GPU for FLUX GGUF models
            if not args.gpu:
                print("\n" + "="*80)
                print("WARNING: FLUX GGUF Q4 MODELS REQUIRE GPU!")
                print("="*80)
                print("You did NOT specify --gpu flag.")
                print("FLUX GGUF Q4 models cannot run on CPU (too slow and memory-intensive).")
                print("Automatically enabling GPU mode...")
                print("="*80 + "\n")
                args.gpu = True
        elif model_family == MODEL_FAMILY_FLUX_BF16:
            args.notebook = "./notebooks/kaggle-flux-schnell-bf16.ipynb"
            print(f"Auto-detected FLUX bf16 model, using notebook: {args.notebook}")
            # Enforce GPU for FLUX bf16 models
            if not args.gpu:
                print("\n" + "="*80)
                print("WARNING: FLUX bf16 MODELS REQUIRE GPU!")
                print("="*80)
                print("You did NOT specify --gpu flag.")
                print("FLUX bf16 models cannot run on CPU (too slow and memory-intensive).")
                print("Automatically enabling GPU mode...")
                print("="*80 + "\n")
                args.gpu = True
        elif model_family in {MODEL_FAMILY_SD35, MODEL_FAMILY_WAN21_CHROMA, MODEL_FAMILY_QWEN_IMAGE}:
            args.notebook = "./notebooks/kaggle-modern-diffusion.ipynb"
            print(f"Auto-detected modern diffusion model, using notebook: {args.notebook}")
            if not args.gpu:
                print("\n" + "="*80)
                print("WARNING: MODERN DIFFUSION MODELS RECOMMEND GPU!")
                print("="*80)
                print("You did NOT specify --gpu flag.")
                print("Auto-enabling GPU mode to reduce memory risk and runtime.")
                print("="*80 + "\n")
                args.gpu = True
        else:
            args.notebook = "./notebooks/kaggle-modern-diffusion.ipynb"
            print(f"Using default generic notebook: {args.notebook}")
    
    # Validate FLUX model dimensions must be multiples of 16
    if model_family == MODEL_FAMILY_FLUX_GGUF:
        # Warn if guidance > 1.0 for FLUX GGUF models
        if args.guidance > 1.0:
            print("\n" + "="*80)
            print("WARNING: HIGH GUIDANCE FOR FLUX GGUF MODEL!")
            print("="*80)
            print(f"You specified --guidance {args.guidance}")
            print(f"For quantized FLUX GGUF models (Q4/Q5/Q6/Q8), the recommended guidance is 0.5-1.0")
            print(f"Higher guidance values may lead to:")
            print(f"  - Over-saturated colors")
            print(f"  - Artifacts and distortions")
            print(f"  - Loss of photorealism")
            print(f"Proceeding anyway, but consider using --guidance 0.5 to 1.0 for better results.")
            print("="*80 + "\n")
        
        if args.img_width % 16 != 0 or args.img_height % 16 != 0:
            print("\n" + "="*80)
            print("VALIDATION ERROR: INVALID FLUX IMAGE DIMENSIONS!")
            print("="*80)
            print(f"FLUX models require dimensions to be multiples of 16.")
            print(f"You provided: {args.img_width}x{args.img_height}")
            print(f"Valid dimensions close to your request:")
            # Suggest nearest valid dimensions
            valid_width = (args.img_width // 16) * 16
            valid_height = (args.img_height // 16) * 16
            print(f"  - {valid_width}x{valid_height}")
            print("="*80 + "\n")
            return
    
    img_size = (args.img_height, args.img_width)

    # Precision is now required; no auto-detection
    logging.info(f"Using explicit precision: {args.precision}")

    # Warn if refiner flags are used for model families that don't support SDXL refiner flow
    if not supports_sdxl_refiner(model_family) and (args.refiner_model_id or args.refiner_guidance or args.refiner_steps or args.refiner_precision or args.refiner_negative_prompt):
        print("\n" + "="*80)
        print("WARNING: REFINER FLAGS IGNORED FOR THIS MODEL FAMILY")
        print("="*80)
        print(f"You specified refiner-related flags with model family: {model_family}.")
        print("The following flags will be ignored:")
        if args.refiner_model_id:
            print(f"  - --refiner-model-id: {args.refiner_model_id}")
        if args.refiner_guidance:
            print(f"  - --refiner-guidance: {args.refiner_guidance}")
        if args.refiner_steps:
            print(f"  - --refiner-steps: {args.refiner_steps}")
        if args.refiner_precision:
            print(f"  - --refiner-precision: {args.refiner_precision}")
        if args.refiner_negative_prompt:
            print(f"  - --refiner-negative-prompt: {args.refiner_negative_prompt}")
        print("Proceeding with generation without refiner...")
        print("="*80 + "\n")

    # Validate arguments including precision availability
    try:
        validate_args(args)
    except ValueError as e:
        print(f"Error: {e}")
        return
    run_pipeline(
        dest_path=dest_path,
        prompts_file=args.prompts_file,
        notebook=args.notebook,
        kernel_path=args.kernel_path,
        gpu=args.gpu,
        model_id=args.model_id,
        refiner_model_id=args.refiner_model_id,
        prompt=args.prompt,
        guidance=args.guidance,
        steps=args.steps,
        precision=args.precision,
        negative_prompt=args.negative_prompt,
        refiner_guidance=args.refiner_guidance,
        refiner_steps=args.refiner_steps,
        refiner_precision=args.refiner_precision,
        refiner_negative_prompt=args.refiner_negative_prompt,
        img_size=img_size,
        model_filename=args.model_filename,
        vae_repo_id=args.vae_repo_id,
        vae_filename=args.vae_filename,
        clip_l_repo_id=args.clip_l_repo_id,
        clip_l_filename=args.clip_l_filename,
        t5xxl_repo_id=args.t5xxl_repo_id,
        t5xxl_filename=args.t5xxl_filename,
        wait_timeout=args.wait_timeout,
        sync_token=args.sync_token,
        index_offset=args.index_offset,
        kernel_id=args.kernel_id,
    )


def _is_kaggle_model(model_id: str) -> bool:
    """
    Check if a model ID refers to a Kaggle model rather than a HuggingFace model.
    Kaggle models typically have usernames that are not standard HF organizations.
    """
    if '/' not in model_id:
        return False
    
    owner = model_id.split('/')[0].lower()
    
    # Known HuggingFace organizations that host models
    hf_orgs = {
        'stabilityai', 'black-forest-labs', 'runwayml', 'compvis', 'openai',
        'google', 'microsoft', 'facebook', 'huggingface', 'meta', 'anthropic',
        'eleutherai', 'bigscience', 'bigcode', 'salesforce', 'amazon', 'nvidia',
        'intel', 'apple', 'tencent', 'baidu', 'alibaba', 'bytedance'
    }
    
    # If owner is not a known HF org, assume it's a Kaggle model
    return owner not in hf_orgs


def _is_flux_gguf_model(model_id: str) -> bool:
    """
    Check if a model ID refers to a FLUX GGUF model.
    These are quantized FLUX models in GGUF format.
    """
    return is_flux_gguf_model(model_id)


def _is_flux_bf16_model(model_id: str) -> bool:
    """
    Check if a model ID refers to a FLUX bf16 model.
    These are black-forest-labs/FLUX.1-schnell or similar full-precision models.
    """
    return is_flux_bf16_model(model_id)


if __name__ == "__main__":
    main()
